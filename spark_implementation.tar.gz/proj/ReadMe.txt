1. Generate matrix of 100 users
   Go to the path where you put "Sample.class" and run "java Sample". The result file is "test". 
   (If you want to change the sample number, just edit "Sample.java" and recompile it "javac Sample.java")
2. The Spark project is maintained via Maven
   2.1 Lauch the client first: "nc -lk 9999" (input format is id_number + 20 doubles. All should be separated by one whitespace)
   2.2 Lauch Spark. Go inside the directory ".../userSift/", and run "spark-submit --class "PickUser" --master spark://localhost:7077 target/userSift-1.0-SNAPSHOT.jar"
   2.3 Put input into the client terminal
   2.3 Check the result, "cat top-*.txt/*"