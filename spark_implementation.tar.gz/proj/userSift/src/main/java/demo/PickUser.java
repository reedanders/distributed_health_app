import java.util.*;

import org.apache.spark.*;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.*;
import org.apache.spark.streaming.*;
import org.apache.spark.streaming.api.java.*;

public class PickUser {
	public static void main(String[] args) throws Exception {
		// Create a local StreamingContext with two working thread and batch interval of 10 second
		SparkConf conf = new SparkConf().setMaster("local[4]").setAppName("FindMatchedUser");
		JavaStreamingContext jssc = new JavaStreamingContext(conf, Durations.seconds(10));

		// RDD containing user samples
		final List<String> samples = jssc.sparkContext().textFile("file:///home/spark/test").collect();

		// Create a DStream that will connect to hostname:port, like localhost:9999
		JavaReceiverInputDStream<String> lines = jssc.socketTextStream("localhost", 9999);

		// Calculate similarity
		JavaDStream<List<Integer>> top = lines.map(
			new Function<String, List<Integer>>() {
				@Override
				public List<Integer> call(String user) throws Exception {
					PickUser one = new PickUser(user);
					List<PickUser> db = new ArrayList<PickUser>();
					for (String s : samples) {
						PickUser u = new PickUser(s);
						u.similar(one);
						db.add(u);
					}
					Collections.sort(db, new Comparator<PickUser>() {
						@Override
						public int compare(PickUser u1, PickUser u2) {
							return new Double(u1.dist).compareTo(u2.dist);
						}
					});
					List<Integer> res = new ArrayList<Integer>();
					int i;
					for (i = 0; i < 5; i++) {
						res.add(db.get(i).id);
					}
					return res;
				}
			});

		top.print();
		top.dstream().saveAsTextFiles("top", "txt");

		jssc.start();              // Start the computation
		jssc.awaitTermination();   // Wait for the computation to terminate
	}

	public int id;
	public double[] mat;
	public double dist;
	private final int N = 20;
	
	public PickUser(String input) {
		String[] items = input.split(" ");
		id = Integer.parseInt(items[0]);
		int i;
		mat = new double[N];
		for (i = 0; i < N; i++) {
			mat[i] = Double.parseDouble(items[i + 1]);
		}
		dist = 0.0;
	}

	public void similar(PickUser u) {
		double res = 0.0;
		int i;
		for (i = 0; i < N; i++) {
			res += Math.pow(mat[i] - u.mat[i], 2);
		}
		dist = Math.sqrt(res);
	}

	public String toString() {
		return "User: " + id;
	}
}
