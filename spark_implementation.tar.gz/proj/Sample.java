import java.io.*;
import java.util.Random;

public class Sample {
	public static void main(String[] args) {
		try {
			BufferedWriter out = new BufferedWriter(new FileWriter("test"));
			Random rnd = new Random();
			int i, j;
			for (i = 0; i < 100; i++) {
				out.write("" + i);
				for (j = 0; j < 20; j++) {
					out.write(" " + rnd.nextDouble());
				}
				out.write("\n");
			}
			out.close();
		} catch (IOException e) {
			System.out.println("Exception " + e);
		}
	}
}
